# Vaylo Sports — web build of the app

This is the real app, compiled for a browser. Not a mock-up, not a landing page.
The live deployment is <https://vaylo-sports-app.netlify.app>.

No application source was changed to make this work. `src/App.tsx:108` already
selects `BrowserRouter` when it is not running inside a native shell, so a
browser build gets clean paths with no code change and no feature flags.

---

## What is in here

| File | What it is |
|---|---|
| `scripts/build-web.cjs` | The build script. Compiles the app to `dist-web/` and writes the two host files. |
| `supabase/config.toml` | Auth config. The `[auth]` block is what makes sign-in work on the web origin. |

---

## How to build and publish

```bash
node scripts/build-web.cjs
cd dist-web && npx netlify deploy --no-build --prod --site=79d67cae-c1cd-4cdb-a72a-14e180145880
```

Three parts of that line are load-bearing.

**`node scripts/build-web.cjs` — not `npx vite build`.** It writes to
`dist-web/` and never touches `dist/`, which is the exact input to
`npx cap sync android`. Overwriting `dist/` between a build and a gradle run is
how an APK ends up shipping the wrong JavaScript. It also writes `_headers` and
`netlify.toml` into the *web* output only, so neither one ships inside the APK,
where they would do nothing.

**`cd dist-web` first.** The Netlify CLI finds `netlify.toml` by walking up from
the working directory. The repository root has a `netlify.toml` for the
marketing and legal site, and its `/* → 404.html` catch-all takes precedence
over `_redirects`. Deploy from the root and every deep link 404s while the app
still works by clicking through it. Nothing errors.

**`--no-build`.** Without it the CLI runs build-command detection, finds several
scripts in the repository `package.json`, and asks a question that a
non-interactive terminal cannot answer. It dies with `ERR_USE_AFTER_CLOSE`
before uploading anything. The output looks like a deploy failure rather than a
missing flag.

---

## Prerequisites

**1. The web origin must be in Supabase's redirect allow-list.** Server config,
not app code — no change to the app can make sign-in work without it, and the
failure mode is a login screen that quietly refuses. `supabase/config.toml`
here has it. Push it with:

```bash
npx supabase config push
```

`site_url` must be the real public origin. If it still points at the dev server,
every password-reset email opens localhost on a machine no user has.

**2. Netlify CLI authenticated** (`npx netlify status` should show your account).

---

## Two separate Netlify sites

| Site | Publishes | Id |
|---|---|---|
| `vaylo-sports.netlify.app` | Legal pages and the app preview | `388b0b24-27ee-472b-9197-aa8eb2782493` |
| `vaylo-sports-app.netlify.app` | This app | `79d67cae-c1cd-4cdb-a72a-14e180145880` |

The repository root is linked to the first. Keep it that way: publishing the app
bundle to the marketing site would replace the 26 legal pages. A test asserts
the app's site id is never the marketing site's.

---

## Verified against the live host

Not asserted from the source — checked on the deployed site:

- `/`, `/training`, `/profile`, `/learning/run-001`, `/packs/abc` all return 200
  and serve the app shell, not the marketing 404 page.
- `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`,
  `Referrer-Policy: strict-origin-when-cross-origin`, `Permissions-Policy`,
  `Cross-Origin-Opener-Policy` are all present. Hashed assets carry
  `Cache-Control: public, max-age=31536000, immutable`.
- Password sign-in completes from the live origin. The token exchange returns
  200, then `profiles`, `get_my_entitlements`, `recovery_logs` and `user_region`
  all return 200 from a browser origin.
- The published deploy's file list was read back from the Netlify API: 159
  files, 153 of them `assets/`, the rest the app's own `public/` files. No
  repository source is served.

---

## Known limits — read this before shipping

**Web OAuth and magic links do not work on a `*.netlify.app` host, by existing
design.** `.netlify.app` is in `PREVIEW_SUFFIXES` in `src/lib/share.ts`, so
`publicAppUrl()` returns an empty string and `authRedirectUrl` throws. The
Google, Discord, Facebook, passkey and "email me a sign-in link" buttons render
and do nothing. Email and password sign-in works.

This is deliberate, not an oversight: `netlify.app` subdomains are claimable by
anyone, so accepting one as an OAuth redirect origin is a genuine token-theft
risk. `nativeReleaseHardening.test.ts` asserts the guard is in place. Lifting it
requires an owned domain, not a configuration tweak — which is also the only way
the `site_url` above becomes something worth having.

**Everything else degrades rather than breaks.** The app detects its platform at
runtime (`src/lib/platform.ts`); native-only paths fall back to their web
equivalents.

---

## The trap worth knowing about

`publish` in `netlify.toml` is resolved against the CLI's *detected base*, which
is the repository root — not against the directory holding the config file. So
`publish = "."` publishes the entire repository. This is not a warning you can
skim past: the deploy reports "Deploy is live!", every check passes, and the
live site quietly serves the marketing pages, the real `package.json` and
`src/*.tsx`. Pinning `base = "."` does not fix it, because `base` is itself
measured from that same root. Only a path from the repository root works.

`src/lib/buildWeb.test.ts` guards this, and the guard was verified by
re-injecting the fault and watching it fail.
