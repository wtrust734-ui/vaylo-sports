import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquare, Plus, Trash2, Edit3, Send, Loader2, Brain, X, ChevronLeft, Database, Info } from "lucide-react";
import { DISCLAIMERS } from "@/config/disclaimers";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getLocalPBs } from "@/lib/athleteDossier";
import AthleteKnowledgePanel from "@/components/coach/AthleteKnowledgePanel";
import { useTranslation } from "react-i18next";
import { isCurrentLanguageRtl } from "@/i18n";
import ReactMarkdown from "react-markdown";

type Msg = { role: "user" | "assistant"; content: string };
type Conv = { id: string; title: string; updated_at: string };
type Memory = { id: string; category: string; key: string; value: string };

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/coach-chat`;

/**
 * Slide-in offset for end-anchored drawers. Physical x transforms don't
 * follow the RTL anchor swap, so the direction is read from the live
 * document instead of caching it — the drawer always slides from its edge.
 */
const drawerSlide = () => (document.documentElement.dir === "rtl" ? "-100%" : "100%");

const Coach = () => {
  const { user, profile, refreshProfile } = useAuth();
  const { toast } = useToast();
  const [convs, setConvs] = useState<Conv[]>([]);
  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [memoryOpen, setMemoryOpen] = useState(false);
  // "What the coach knows about you" — the dossier, shown to the athlete.
  const [knowledgeOpen, setKnowledgeOpen] = useState(false);
  const [memories, setMemories] = useState<Memory[]>([]);
  const [editingTitle, setEditingTitle] = useState<string | null>(null);
  const [newTitle, setNewTitle] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  // What the screen believes is open. The select handler below reloads
  // history explicitly, and this ref decides whether that late response is
  // still wanted when it lands.
  const activeConvRef = useRef<string | null>(null);
  activeConvRef.current = activeConv;

  // History loader, shared by the effect below and by selecting a
  // conversation (including re-selecting the current one, which changes no
  // state and would otherwise show whatever is on screen rather than what
  // is stored). Both guards below ignore delayed responses from a previous
  // account or conversation, so switching either mid-fetch cannot paint the
  // wrong thread.
  const loadMessages = async (conversationId: string, userId: string) => {
    // Conversation replay reads two fields; the table carries none of the
    // heavy ones here but "*" pulled every column into the history map for
    // nothing (audit finding 3.1).
    const { data } = await supabase.from("coach_messages").select("role, content, conversation_id, user_id, created_at").eq("conversation_id", conversationId)
      .order("created_at", { ascending: true });
    return { conversationId, userId, rows: (data || []).map(m => ({ role: m.role as "user" | "assistant", content: m.content })) };
  };

  useEffect(() => {
    if (!user) { setConvs([]); setActiveConv(null); setMessages([]); return; }
    let alive = true;
    const userId = user.id;
    supabase.from("coach_conversations").select("id, title, user_id, updated_at").eq("user_id", userId)
      .order("updated_at", { ascending: false }).then(({ data }) => {
        if (!alive) return;
        setConvs(data || []);
      });
    return () => { alive = false; };
  }, [user]);

  useEffect(() => {
    if (!activeConv || !user) { setMessages([]); return; }
    let alive = true;
    const conversationId = activeConv;
    const userId = user.id;
    loadMessages(conversationId, userId).then(({ rows }) => {
      if (!alive) return;
      setMessages(rows);
    });
    return () => { alive = false; };
  }, [activeConv, user]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const loadMemories = async () => {
    if (!user) return;
    const { data } = await supabase.from("coach_memories").select("*").eq("user_id", user.id).order("updated_at", { ascending: false });
    setMemories(data || []);
  };

  const createConversation = async () => {
    if (!user) return;
    const { data, error } = await supabase.from("coach_conversations").insert({ user_id: user.id, title: "New Chat" }).select().single();
    if (error) { toast({ title: "Couldn't start a new chat", description: error.message, variant: "destructive" }); return; }
    if (data) {
      setConvs(prev => [data, ...prev]);
      setActiveConv(data.id);
      setMessages([]);
      setSidebarOpen(false);
    }
  };

  const deleteConversation = async (id: string) => {
    const { error: msgError } = await supabase.from("coach_messages").delete().eq("conversation_id", id);
    const { error: convError } = await supabase.from("coach_conversations").delete().eq("id", id);
    if (msgError || convError) {
      toast({ title: "Couldn't delete the chat", description: (msgError || convError)!.message, variant: "destructive" });
      return;
    }
    setConvs(prev => prev.filter(c => c.id !== id));
    if (activeConv === id) { setActiveConv(null); setMessages([]); }
  };

  const renameConversation = async (id: string) => {
    if (!newTitle.trim()) return;
    const { error } = await supabase.from("coach_conversations").update({ title: newTitle.trim() }).eq("id", id);
    if (error) { toast({ title: "Couldn't rename the chat", description: error.message, variant: "destructive" }); return; }
    setConvs(prev => prev.map(c => c.id === id ? { ...c, title: newTitle.trim() } : c));
    setEditingTitle(null);
    setNewTitle("");
  };

  const deleteMemory = async (id: string) => {
    const { error } = await supabase.from("coach_memories").delete().eq("id", id);
    if (error) { toast({ title: "Couldn't delete that memory", description: error.message, variant: "destructive" }); return; }
    setMemories(prev => prev.filter(m => m.id !== id));
  };

  // Memories are persisted by the coach-chat edge function now (it sees the
  // full streamed reply, so a closed tab or a dropped frame can no longer drop
  // a memory, and a doctored client can no longer fabricate one). The client
  // only refreshes its memory list after each reply; nothing writes here.
  const parseMemorySaves = useCallback(async (_text: string) => {
    if (!user) return;
    // Re-read the user's memories so the sidebar reflects what the server saved.
    const { data } = await supabase
      .from("coach_memories")
      .select("*")
      .eq("user_id", user.id)
      .order("updated_at", { ascending: false });
    setMemories(data ?? []);
  }, [user]);

  const send = async (text: string) => {
    if (!text.trim() || loading || !user) return;
    // Locked before conversation creation, not after: two taps before the
    // first insert resolves must not create two conversations.
    setLoading(true);

    let convId = activeConv;
    if (!convId) {
      const { data, error } = await supabase.from("coach_conversations").insert({ user_id: user.id, title: text.slice(0, 40) }).select().single();
      if (error || !data) { toast({ title: "Couldn't start the chat", description: error?.message ?? "Please try again.", variant: "destructive" }); setLoading(false); return; }
      convId = data.id;
      setConvs(prev => [data, ...prev]);
      setActiveConv(data.id);
    }

    const userMsg: Msg = { role: "user", content: text };
    setMessages(prev => [...prev, userMsg]);
    setInput("");

    const { error: saveMsgError } = await supabase.from("coach_messages").insert({ conversation_id: convId, user_id: user.id, role: "user", content: text });
    if (saveMsgError) {
      // Without the saved message the thread would be inconsistent on reload.
      setMessages(prev => prev.filter(m => m !== userMsg));
      setLoading(false);
      toast({ title: "Message not sent", description: saveMsgError.message, variant: "destructive" });
      return;
    }
    const { error: touchError } = await supabase.from("coach_conversations").update({ updated_at: new Date().toISOString() }).eq("id", convId);
    if (touchError) console.error("conversation timestamp update failed:", touchError.message);

    let assistantSoFar = "";
    try {
      const session = await supabase.auth.getSession();
      const token = session.data.session?.access_token;

      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ messages: [...messages, userMsg], conversationId: convId, pbs: getLocalPBs().slice(0, 20).map((p) => ({ metric: p.metric, value: p.value, unit: p.unit, date: p.date })) }),
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({ error: "Request failed" }));
        toast({ title: "Coach Error", description: err.error || "Something went wrong", variant: "destructive" });
        setLoading(false);
        await refreshProfile();
        return;
      }

      // A missing body means the upstream never answered at all — say so
      // explicitly rather than throwing on `resp.body!`.
      if (!resp.body) {
        setMessages(prev => prev.filter(m => m !== userMsg));
        setLoading(false);
        toast({ title: "Coach Error", description: "The reply came back empty. Nothing was spent — please try again.", variant: "destructive" });
        await refreshProfile();
        return;
      }
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let completed = false;
      let malformed = false;

      const applyContent = (content: string) => {
        assistantSoFar += content;
        setMessages(prev => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant") {
            return prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantSoFar } : m);
          }
          return [...prev, { role: "assistant", content: assistantSoFar }];
        });
      };

      // One frame per line. A line that is not valid JSON is kept for the
      // next chunk only while the stream is still open — a truncated frame
      // split across chunks — and is otherwise reported, never spun on.
      const consumeLines = (final: boolean) => {
        let newlineIdx: number;
        while ((newlineIdx = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, newlineIdx);
          buffer = buffer.slice(newlineIdx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") { completed = true; break; }
          if (!jsonStr) continue;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (typeof content === "string" && content) applyContent(content);
          } catch {
            if (final) { malformed = true; }
            else { buffer = line + "\n" + buffer; break; }
          }
        }
      };

      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          // Split UTF-8 stays split-safe: the decoder holds partial code
          // points across chunks, and is flushed once the stream ends.
          buffer += decoder.decode(value, { stream: true });
          consumeLines(false);
          // DONE is terminal: stop reading and release the lock instead of
          // draining whatever the server sends after it.
          if (completed) { await reader.cancel().catch(() => undefined); break; }
        }
      } finally {
        try { reader.releaseLock(); } catch { /* already released */ }
      }
      buffer += decoder.decode();
      // An unterminated final line is still a frame: process it rather than
      // dropping the tail of the reply.
      if (buffer.trim()) buffer += "\n";
      consumeLines(true);

      if (malformed || (!completed && !assistantSoFar)) {
        // Nothing usable arrived. The user's message is already saved, so it
        // stays as a retryable reply — but the failure is said out loud.
        setLoading(false);
        toast({ title: "Coach Error", description: "The reply was interrupted before anything arrived. Your message is saved — please try again.", variant: "destructive" });
        await refreshProfile();
        return;
      }
      if (!completed && assistantSoFar) {
        // Interrupted mid-reply: what arrived is shown, labelled as what it
        // is, so a cut-off sentence never reads as the coach's full answer.
        assistantSoFar += "\n\n(Response incomplete — the connection was interrupted.)";
        setMessages(prev => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant") {
            return prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantSoFar } : m);
          }
          return [...prev, { role: "assistant", content: assistantSoFar }];
        });
      }

      if (assistantSoFar) {
        await supabase.from("coach_messages").insert({ conversation_id: convId, user_id: user.id, role: "assistant", content: assistantSoFar });
        await parseMemorySaves(assistantSoFar);
      }
      await refreshProfile();
    } catch (e) {
      console.error(e);
      toast({ title: "Error", description: "Failed to connect to Vaylo Sports Coach", variant: "destructive" });
    }
    setLoading(false);
  };

  const cleanContent = (text: string) => text.replace(/\[MEMORY_SAVE:[^\]]+\]/g, "").trim();



  // Welcome screen — no quick actions, just chat
  if (!activeConv && messages.length === 0) {
    return (
      <div className="min-h-screen bg-background pb-24">
        <div className="px-5 pb-3 pt-[var(--vaylo-screen-top)] flex items-center justify-between">
          <div>
            <motion.h1 initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-xl font-display font-bold">Vaylo Sports Coach</motion.h1>
            <p className="text-xs text-muted-foreground">3 credits per prompt · {profile?.credits ?? 0} credits</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setKnowledgeOpen(true)}
              aria-label="What the coach knows about you"
              className="p-2 rounded-xl bg-card border border-border"
            >
              <Info size={16} className="text-muted-foreground" />
            </button>
            <button onClick={() => { setMemoryOpen(true); loadMemories(); }} className="p-2 rounded-xl bg-card border border-border">
              <Database size={16} className="text-muted-foreground" />
            </button>
            <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-xl bg-card border border-border">
              <MessageSquare size={16} className="text-muted-foreground" />
            </button>
          </div>
        </div>

        <div className="px-5 flex flex-col items-center justify-center" style={{ minHeight: "55vh" }}>
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring" }}
            className="w-20 h-20 rounded-2xl bg-primary/10 border-2 border-primary/30 flex items-center justify-center mb-6">
            <Brain size={36} className="text-primary" />
          </motion.div>
          <h2 className="text-lg font-display font-bold mb-1">Elite AI Coach</h2>
          <p className="text-xs text-muted-foreground text-center max-w-xs mb-3">Direct. Analytical. No fluff. Creates training plans, nutrition plans, and remembers your data.</p>
          {/* The coach is a language model. Saying so once, where the athlete
              starts, is more honest than a legal page they never open. */}
          <p className="text-[11px] leading-relaxed text-muted-foreground text-center max-w-xs mb-6">
            {DISCLAIMERS.aiEstimate.full}
          </p>

          {/* Input bar directly on welcome */}
          <div className="w-full mb-4">
            <div className="flex gap-2 items-end">
              <textarea value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
                placeholder="Ask your coach anything..." rows={2}
                className="flex-1 bg-card border border-border rounded-xl px-4 py-3 text-sm resize-none max-h-32 focus:outline-none focus:ring-2 focus:ring-primary/50" />
              <motion.button onClick={() => send(input)} disabled={!input.trim() || loading} whileTap={{ scale: 0.9 }}
                className="bg-gradient-primary text-primary-foreground p-3 rounded-xl disabled:opacity-40 shadow-glow">
                <Send size={18} />
              </motion.button>
            </div>
          </div>

          <button onClick={createConversation}
            className="flex items-center gap-2 text-sm text-primary font-semibold">
            <Plus size={16} /> New Chat
          </button>
        </div>

        <ConvSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} convs={convs}
          onSelect={(id) => {
            // Reloaded on every select, including re-selecting the current
            // conversation: the effect above only runs when the id changes,
            // so without this the screen could show a stale thread.
            setActiveConv(id);
            activeConvRef.current = id;
            setSidebarOpen(false);
            if (user) {
              const userId = user.id;
              void loadMessages(id, userId).then(({ rows }) => {
                if (activeConvRef.current !== id) return;
                setMessages(rows);
              });
            }
          }} onDelete={deleteConversation}
          onNew={createConversation} editingTitle={editingTitle} setEditingTitle={setEditingTitle}
          newTitle={newTitle} setNewTitle={setNewTitle} onRename={renameConversation} />
        <MemoryPanel open={memoryOpen} onClose={() => setMemoryOpen(false)} memories={memories} onDelete={deleteMemory} />
        <AthleteKnowledgePanel open={knowledgeOpen} onClose={() => setKnowledgeOpen(false)} />
      </div>
    );
  }

  // Chat view
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="px-4 pt-[var(--vaylo-screen-top)] pb-3 flex items-center gap-3 border-b border-border">
        <button onClick={() => { setActiveConv(null); setMessages([]); }} className="p-1.5 text-muted-foreground"><ChevronLeft size={20} /></button>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold truncate">{convs.find(c => c.id === activeConv)?.title || "New Chat"}</p>
          <p className="text-[12px] text-muted-foreground">{profile?.credits ?? 0} credits remaining</p>
        </div>
        <div className="flex gap-1.5">
          <button
            onClick={() => setKnowledgeOpen(true)}
            aria-label="What the coach knows about you"
            className="p-1.5 text-muted-foreground"
          >
            <Info size={16} />
          </button>
          <button onClick={() => { setMemoryOpen(true); loadMemories(); }} className="p-1.5 text-muted-foreground"><Database size={16} /></button>
          <button onClick={() => setSidebarOpen(true)} className="p-1.5 text-muted-foreground"><MessageSquare size={16} /></button>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-4 py-4 space-y-4 pb-40">
        {messages.map((m, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            {/* `min-w-0` is load-bearing: a flex item defaults to min-width:auto,
                so a long unbroken string inside an AI reply — a URL, a UUID, a
                pasted training block — sets the item's floor and drags the whole
                row wider than the phone. `break-words` then wraps it instead. */}
            <div className={`min-w-0 max-w-[85%] rounded-2xl px-4 py-3 text-sm break-words ${
              m.role === "user"
                ? "bg-primary text-primary-foreground rounded-br-md"
                : "bg-card border border-border rounded-bl-md"
            }`}>
              {m.role === "assistant" ? (
                <div className="prose prose-sm prose-invert max-w-none break-words overflow-wrap-anywhere [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                  <ReactMarkdown>{cleanContent(m.content)}</ReactMarkdown>
                </div>
              ) : m.content}
            </div>
          </motion.div>
        ))}
        {loading && messages[messages.length - 1]?.role !== "assistant" && (
          <div className="flex justify-start">
            <div className="bg-card border border-border rounded-2xl rounded-bl-md px-4 py-3">
              <Loader2 size={16} className="animate-spin text-primary" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Lifted clear of the mobile tab bar.

          `bottom-tab` was not a real class — it is not in the `spacing` scale in
          tailwind.config, so `bottom: bottom-tab` was invalid CSS and this
          composer had no bottom offset at all. It rendered on top of the tab
          bar, which is what made the send button hard to hit. The value below
          matches the tab bar's own geometry (64px of nav plus its 8px offset)
          and matches QuickActionSheet, so the three agree. */}
      <div className="fixed bottom-[calc(var(--vaylo-inset-bottom)+7rem)] lg:bottom-0 left-0 right-0 z-40 bg-background/95 backdrop-blur border-t border-border px-3 sm:px-4 py-3 lg:pb-[calc(var(--vaylo-inset-bottom)+12px)]">
        <div className="flex gap-2 items-end">
          <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }}
            placeholder="Ask your coach..." rows={1}
            className="flex-1 bg-card border border-border rounded-xl px-4 py-3 text-sm resize-none max-h-32" />
          <button onClick={() => send(input)} disabled={!input.trim() || loading}
            className="bg-primary text-primary-foreground p-3 rounded-xl disabled:opacity-40">
            <Send size={18} />
          </button>
        </div>
      </div>

      <ConvSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} convs={convs}
        onSelect={(id) => { setActiveConv(id); setSidebarOpen(false); }} onDelete={deleteConversation}
        onNew={createConversation} editingTitle={editingTitle} setEditingTitle={setEditingTitle}
        newTitle={newTitle} setNewTitle={setNewTitle} onRename={renameConversation} />
      <MemoryPanel open={memoryOpen} onClose={() => setMemoryOpen(false)} memories={memories} onDelete={deleteMemory} />
      <AthleteKnowledgePanel open={knowledgeOpen} onClose={() => setKnowledgeOpen(false)} />
    </div>
  );
};

const ConvSidebar = ({ open, onClose, convs, onSelect, onDelete, onNew, editingTitle, setEditingTitle, newTitle, setNewTitle, onRename }: {
  open: boolean; onClose: () => void; convs: Conv[]; onSelect: (id: string) => void;
  onDelete: (id: string) => void; onNew: () => void;
  editingTitle: string | null; setEditingTitle: (id: string | null) => void;
  newTitle: string; setNewTitle: (t: string) => void; onRename: (id: string) => void;
}) => (
  <AnimatePresence>
    {open && (
      <>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 bg-background/70 backdrop-blur-sm z-[59]" onClick={onClose} />
        <motion.div initial={{ x: drawerSlide() }} animate={{ x: 0 }} exit={{ x: drawerSlide() }}
          transition={{ type: "spring", stiffness: 400, damping: 35 }}
          className="fixed end-0 top-0 bottom-0 w-72 bg-card/95 backdrop-blur-xl border-s border-border z-[59] flex flex-col">
          <div className="p-4 border-b border-border flex items-center justify-between pt-[max(1rem,var(--vaylo-inset-top))]">
            <span className="font-display font-bold text-sm">Conversations</span>
            <button onClick={onClose}><X size={18} className="text-muted-foreground" /></button>
          </div>
          <div className="p-3">
            <button onClick={onNew} className="w-full flex items-center gap-2 text-sm font-semibold text-primary bg-primary/10 rounded-xl px-3 py-2.5">
              <Plus size={16} /> New Chat
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-3 pb-[max(0.75rem,var(--vaylo-inset-bottom))] space-y-1">
            {convs.map(c => (
              <div key={c.id} className="flex items-center gap-1 group">
                {editingTitle === c.id ? (
                  <input value={newTitle} onChange={e => setNewTitle(e.target.value)} autoFocus
                    onKeyDown={e => e.key === "Enter" && onRename(c.id)}
                    onBlur={() => setEditingTitle(null)}
                    className="flex-1 bg-muted border border-border rounded-lg px-2 py-1.5 text-xs" />
                ) : (
                  <button onClick={() => onSelect(c.id)}
                    className="flex-1 text-start text-xs py-2 px-2 rounded-lg hover:bg-muted truncate">{c.title}</button>
                )}
                <button onClick={() => { setEditingTitle(c.id); setNewTitle(c.title); }}
                  className="opacity-0 group-hover:opacity-100 p-1 text-muted-foreground"><Edit3 size={12} /></button>
                <button onClick={() => onDelete(c.id)}
                  className="opacity-0 group-hover:opacity-100 p-1 text-destructive"><Trash2 size={12} /></button>
              </div>
            ))}
          </div>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);

const MemoryPanel = ({ open, onClose, memories, onDelete }: {
  open: boolean; onClose: () => void; memories: Memory[]; onDelete: (id: string) => void;
}) => (
  <AnimatePresence>
    {open && (
      <>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 bg-background/70 backdrop-blur-sm z-[59]" onClick={onClose} />
        <motion.div initial={{ x: drawerSlide() }} animate={{ x: 0 }} exit={{ x: drawerSlide() }}
          transition={{ type: "spring", stiffness: 400, damping: 35 }}
          className="fixed end-0 top-0 bottom-0 w-72 bg-card/95 backdrop-blur-xl border-s border-border z-[59] flex flex-col">
          <div className="p-4 border-b border-border flex items-center justify-between pt-[max(1rem,var(--vaylo-inset-top))]">
            <span className="font-display font-bold text-sm">Memory Bank</span>
            <button onClick={onClose}><X size={18} className="text-muted-foreground" /></button>
          </div>
          <div className="flex-1 overflow-y-auto px-3 py-3 pb-[max(0.75rem,var(--vaylo-inset-bottom))] space-y-2">
            {memories.length === 0 && <p className="text-xs text-muted-foreground text-center py-8">No memories stored yet. Chat with your coach and share data to build your profile.</p>}
            {memories.map(m => (
              <div key={m.id} className="bg-muted/30 rounded-xl p-3 group">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[12px] text-primary font-semibold uppercase">{m.category}</span>
                  <button onClick={() => onDelete(m.id)} className="opacity-0 group-hover:opacity-100 text-destructive"><Trash2 size={10} /></button>
                </div>
                <p className="text-xs font-semibold">{m.key}</p>
                <p className="text-[12px] text-muted-foreground">{m.value}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);

export default Coach;
