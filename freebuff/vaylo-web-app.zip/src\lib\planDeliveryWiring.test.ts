// ============================================================================
// PLAN DELIVERY WIRING — a charged plan that does not save is money lost
// ----------------------------------------------------------------------------
// `generate-plan` charges before it writes a word, and the client is what stores
// the finished plan. That split has one bad window: the function returns a plan
// the athlete has paid for, and the insert into `training_plans` fails — leaving
// a charge with nothing behind it. This is the failure the athlete reported
// ("it took my credits and did not give me a plan"), so the contract is pinned
// here across both files rather than trusted to review.
//
// Three things must hold:
//   1. the insert is attempted more than once, because the plan is in memory and
//      the failure is usually transient;
//   2. when it still fails, the athlete is told NOT to create the plan again —
//      which would charge a second time — and is pointed at support;
//   3. that message comes before any success toast, so the screen can never show
//      "Plan Created!" for a plan that is not in the database.
// ============================================================================

import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const read = (p: string) => readFileSync(path.resolve(__dirname, "../.." + p), "utf8");

const training = read("/src/pages/Training.tsx");
const nutrition = read("/src/pages/Nutrition.tsx");

describe("a plan the athlete paid for is either saved or reported", () => {
  it("retries the insert instead of giving up on the first failure", () => {
    // Two attempts of the same row: the plan data is already in hand, so the
    // only cost of a retry is a moment.
    expect(training).toMatch(/for\s*\(let attempt = 1; attempt <= 2; attempt\+\+\)/);
    expect(training).toContain(".insert(planRow)");
  });

  it("tells the athlete not to re-create the plan, in the branch that gives up", () => {
    // Scoped to the failing branch, not the whole file. A file-wide search is
    // satisfied by a comment — and this file is mostly comments — so the three
    // phrases are only evidence when they sit in the code that runs after the
    // insert has failed and before the function returns.
    const failureBranch = training.indexOf("Your plan was written but could not be saved");
    expect(failureBranch, "the plan-not-saved branch is gone").toBeGreaterThan(-1);
    const branch = training.slice(failureBranch, training.indexOf("return;", failureBranch));

    expect(branch).toMatch(/do not create it again/i);
    expect(branch).toMatch(/second time/i);
    // ...and where to go to get the credits back, since the client cannot
    // refund a charge itself (credits_grant is service-role only).
    expect(branch).toMatch(/contact support/i);
  });

  it("never reaches the success toast when the save failed", () => {
    const failureBranch = training.indexOf("Your plan was written but could not be saved");
    const successToast = training.indexOf('title: "Plan Created!');

    expect(failureBranch).toBeGreaterThan(-1);
    expect(successToast).toBeGreaterThan(failureBranch);
    // The failure branch has to leave the function before the success path can
    // run — a toast alone would still let the wizard close on a missing plan.
    expect(training.slice(failureBranch, successToast)).toMatch(/return;/);
  });

  it("pins equivalent no-recreation, support, and failure-before-success handling for nutrition plans", () => {
    const failureBranch = nutrition.indexOf("Your plan was written but not saved");
    const successToast = nutrition.indexOf('title: "Your plan is ready 🥗"');
    expect(failureBranch).toBeGreaterThan(-1);
    expect(successToast).toBeGreaterThan(failureBranch);
    const failureWindow = nutrition.slice(failureBranch, successToast);
    expect(failureWindow).toMatch(/do not generate it again/i);
    expect(failureWindow).toMatch(/second time/i);
    expect(failureWindow).toMatch(/contact support/i);
    expect(failureWindow).toMatch(/return;/);
  });
});
