import { describe, expect, it } from "vitest"
import { createRequire } from "node:module"

const require = createRequire(import.meta.url)
const { scanText } = require("../../scripts/secret-scan.mjs") as { scanText: (text: string) => { id: string }[] }

/**
 * These tests exist because the first version of the scanner did not work.
 *
 * It was written, run, and reported PASS on a repository that still contained
 * the reviewer password in five commits — because the rules only matched
 * `password: "..."` and the leak was written as
 * `process.env.UI_PASSWORD || "..."`. A credential scanner with no test
 * asserting it catches the known credential is a scanner whose green run means
 * nothing, which is exactly the failure it was added to prevent.
 *
 * The positive cases below are therefore pinned to the real shape of the real
 * leak, not to an invented one.
 */

const ids = (text: string) => scanText(text).map((h) => h.id)

/**
 * The fixtures below are the *shape* of the leak, never its value.
 *
 * Writing the real password here would have been the worst possible version of
 * this change: it would take a credential that is currently recoverable only
 * from history and put it in the tip of main, where every future clone reads it.
 * The assertion the scanner has to pass is about the line's structure, so the
 * value can be anything of the same form.
 */
const FAKE_PASSWORD = "NotTheRealOne!0000"
const FAKE_EMAIL = "someone.else@example.com"

describe("secret-scan catches the reviewer password that was committed", () => {
  // The shape of scripts/ui-audit.mjs at commit e527b548. The credential is the
  // fallback after `||`, not the assignment after `=`.
  it("flags the env-var fallback the password was actually written as", () => {
    const line = `const PASSWORD = process.env.UI_PASSWORD || "${FAKE_PASSWORD}";`
    expect(ids(line)).toContain("env-fallback-literal")
  })

  it("flags the email literal on the adjacent line of the same file", () => {
    const line = `const EMAIL = process.env.UI_EMAIL || "${FAKE_EMAIL}";`
    expect(ids(line)).toContain("env-fallback-literal")
  })

  it("flags the direct object-literal form too", () => {
    expect(ids(`const cfg = { password: "${FAKE_PASSWORD}" };`)).toContain(
      "hardcoded-password",
    )
  })
})

describe("secret-scan still catches the other credential shapes", () => {
  it("flags a JWT", () => {
    // Header and payload are real (the payload says service_role, because that
    // is the case that matters); the signature is filler.
    const jwt =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoic2VydmljZV9yb2xlIn0.abcdefghijklmnopqrstuvwxyz012345"
    expect(ids(`const k = "${jwt}"`)).toContain("jwt")
  })

  it("flags a private key with real material after the header", () => {
    const pem = [
      "-----BEGIN PRIVATE KEY-----",
      "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQ==",
      "-----END PRIVATE KEY-----",
    ].join("\n")
    expect(ids(pem)).toContain("private-key")
  })

  it("flags an AWS access key id", () => {
    expect(ids('const id = "AKIAIOSFODNN7EXAMPLE";')).toContain("aws-access-key")
  })

  it("flags an OpenAI key", () => {
    // The example key from OpenAI's own documentation, not a working one.
    expect(ids('const k = "sk-proj-abcdefghij0123456789ABCDEFGHIJ";')).toContain("openai-key")
  })
})

describe("secret-scan does not cry wolf on this repository's real code", () => {
  // Each of these is a real line from this repository, or the real shape of one.
  // A scanner that fires on any of them would be turned off within a day, and a
  // scanner that is turned off catches nothing.

  it("ignores the publishable key, which is designed to be public", () => {
    const line = 'apikey:"sb_publishable_abcdefghijklmnopqrstuvwxyz012345"'
    expect(ids(line)).not.toContain("hardcoded-password")
    expect(ids(line)).not.toContain("env-fallback-literal")
  })

  it("ignores the password placeholder in the audit script's own error message", () => {
    expect(ids('{ "email": "...", "password": "..." }')).not.toContain("hardcoded-password")
  })

  it("ignores the PEM header used as documentation placeholder", () => {
    const doc = 'GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\\n...\\n-----END PRIVATE KEY-----"'
    expect(ids(doc)).not.toContain("private-key")
  })

  it("ignores an env-var reference as a fallback", () => {
    expect(ids('const TOKEN = process.env.SOMETHING || process.env.OTHER')).not.toContain(
      "env-fallback-literal",
    )
  })

  it("ignores placeholder words as credential values", () => {
    for (const value of ["changeme", "your-api-key", "placeholder", "redacted", "***"]) {
      expect(ids(`const apiKey = getenv("X") || "${value}"`)).not.toContain(
        "env-fallback-literal",
      )
    }
  })

  it("ignores the auth grant_type, which says password without being one", () => {
    expect(ids("await fetchJson(`${SUPA_URL}/auth/v1/token?grant_type=password`)")).toEqual([])
  })

  it("ignores a fallback whose variable is not credential-shaped", () => {
    expect(ids('const LABEL = process.env.LOCALE || "en-GB"')).not.toContain(
      "env-fallback-literal",
    )
  })

  it("ignores an empty-string and whitespace fallback", () => {
    expect(ids('const SECRET = process.env.SECRET || ""')).not.toContain("env-fallback-literal")
  })

  // A redacted placeholder with an apostrophe in it. This failed once: the value
  // pattern was `[^"']`, which truncated at the apostrophe, leaving a short
  // fragment that cleared the reject list — so the scanner fired on the
  // placeholder that exists precisely to stop it firing.
  it("ignores a redacted placeholder that contains an apostrophe", () => {
    const doc = `const EMAIL = process.env.UI_EMAIL || "<the review account's address>";`
    expect(ids(doc)).not.toContain("env-fallback-literal")
  })
})

describe("secret-scan handles quotes inside the value", () => {
  // A password with an apostrophe is ordinary. A scanner that truncates at the
  // first one is blind to a whole class of real credentials, and — worse — the
  // truncated fragment is short enough to pass the placeholder reject list,
  // which turns the bug into a false positive on the very redactions that are
  // supposed to prevent one.
  it("flags a single-quoted password containing an apostrophe", () => {
    expect(ids(`const password = "dont'guess-me-1234";`)).toContain("hardcoded-password")
  })

  it("flags a double-quoted password containing an apostrophe", () => {
    expect(ids(`const password = "don't guess me 12345";`)).toContain("hardcoded-password")
  })

  it("flags a fallback value containing an apostrophe", () => {
    const line = `const PASSWORD = process.env.PW || "it's-not-the-real-one-9";`
    expect(ids(line)).toContain("env-fallback-literal")
  })

  it("flags a single-quoted fallback and does not run past the closing quote", () => {
    // The value ends at its own quote, not at the next one of the other kind.
    const line = `const PASSWORD = process.env.PW || 'x' + suffix;`
    expect(ids(line)).not.toContain("env-fallback-literal")
  })
})

describe("secret-scan calibration for the 2026-10-06 audit false positives", () => {
  // `npm run secret:scan` reported three findings, each verified benign. They
  // are pinned here so the fixes stay fixed: a scanner whose false positives
  // are allowlisted gets switched off, and the next real credential walks
  // through the hole that leaves.

  it("ignores a secret generated by command substitution at runtime", () => {
    // scripts/set-waitlist-cron-secret.sh:31 — the value is produced by
    // `openssl rand`, so no credential exists on this line.
    const line = 'SECRET="$(openssl rand -hex 32 2>/dev/null || node -e randomBytes)"'
    expect(ids(line)).not.toContain("hardcoded-password")
  })

  it("ignores the publishable key in an ANON_KEY-named assignment", () => {
    // signups-admin/app.js:14 — designed to ship in a browser.
    const line = 'var SUPABASE_ANON_KEY = "sb_publishable_-4WhrnnT9m8gzQ4nUzPQkg_SE_kevgg";'
    expect(ids(line)).not.toContain("supabase-legacy-key")
    expect(ids(line)).not.toContain("jwt")
  })

  it("still flags a legacy JWT-shaped anon key assignment", () => {
    // The shape the rule exists for: retired anon key = JWT = indistinguishable
    // from a service-role key by shape alone.
    const jwt =
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiJ9.abcdefghijklmnopqrstuvwxyz012345"
    expect(ids(`var SUPABASE_ANON_KEY = "${jwt}";`)).toContain("supabase-legacy-key")
  })

  it("ignores a URL parameter parse whose token= sits inside a string literal", () => {
    // supabase/functions/support-request-unsubscribe/index.ts:28 — the quote
    // after `token=` closes the string literal "token=", not a credential.
    const line = 'const peek = (u) => u.split("token=")[1] ?? ""'
    expect(ids(line)).not.toContain("hardcoded-password")
  })

  it("ignores translated password field labels in generated JS dictionaries", () => {
    for (const label of ["Password", "Contraseña", "Passwort", "Wachtwoord", "Mot de passe", "كلمة المرور"]) {
      expect(ids(`const locale = { password: "${label}" };`)).not.toContain("hardcoded-password")
    }
  })

  it("ignores a minified runtime fragment captured after a token query key", () => {
    expect(ids('token:",u)),this.rest=new Qr(new URL("rest/v1",i).href')).not.toContain("hardcoded-password")
  })
})
