# Google Play closed testing

Everything needed to get Vaylo Sports into a closed test track, in the order Play
Console asks for it. Written against the state of this repository, so where a value
is quoted — package name, version code, signing fingerprint — it came from the
files here rather than from memory.

Read §0 first: two decisions change what you answer in §4, and §"What only you can
provide" is the list of things that will stop you.

---

## Status

| | |
|---|---|
| Application ID | `com.vaylosports.app` |
| App name (target) | `VAYLO Sports` |
| minSdk / targetSdk | 26 (Android 8.0) / 36 |
| Version code / name | `46` / `1.2.43` (default in `android/app/build.gradle`) — the audit-remediation release, built and verified 2026-10-15; both overridable at build time. Bump for every upload.
| Release signing | Configured. Upload key `upload` in `android/upload-keystore.jks` |
| Upload key SHA-256 | Local upload key; verify fingerprint with `apksigner verify --print-certs` |
| Upload key valid until | 2054-02-13 (Play requires validity past 2033) |
| Signed bundle in CI | `.github/workflows/android-release.yml` (manual or `v*` tag) |
| Privacy policy / terms / deletion pages | Written and **live** (see §1) |
| Support email | `vaylosportssupport@gmail.com` |
| Public app URL | Not configured — no owned canonical domain yet |
| Store icon + feature graphic | Generated into `store/` |
| Screenshots | **Not yet captured** — see §6 |
| Feature flags | Wearable sync **on** (Health Connect); GPS tracking removed; coach marketplace **off** — see `src/config/featureFlags.ts` |
| AI features | **Live and verified 2026-10-15** — `ai:health` reported 8/8 answering with real provider calls (incl. Gemini video, cost 45 credits); `OPENAI_API_KEY`, `GOOGLE_API` + `GOOGLE_VIDEO_API` all set as function secrets |

---

## What only you can provide

Ordered by how early they block you.

1. **A Play Console developer account.** Note the account *type*: personal,
   non-organisation accounts created after 13 November 2023 must run a closed test
   with **at least 12 testers for 14 continuous days** before they can even apply
   for production access. An organisation account has no such gate. If you have a
   registered business, the organisation route is materially faster.
2. **A demo account for the reviewer** (email + password), for the App access
   declaration in §4. The app is behind a login, so without this a reviewer sees
   the sign-in screen and nothing else.

   One already exists and is the same account the UI audit signs in with:
   `ui.review.20260928@example.com`. It is confirmed (email confirmation is now
   required at signup) and holds the current 260-credit starting grant — topped
   up on 2026-10-15 because it predated the new economy with a balance of 0. Its
   password is in
   `.freebuff/ui-audit.local.json` in the working checkout — outside the
   repository on purpose, since the same password gets pasted into the Play
   listing anyway and one copy is easier to rotate than two.

   Three things to do with it. Put the credentials in the App access declaration
   before you submit; keep sign-in working after any auth change (verified
   2026-10-15); and rotate the password (or zero the credits) the day the review
   is done, because a reviewer account that
   is still reachable after launch is an open door, and deleting it then means
   re-doing this section for the next reviewer.
3. **AI provider secrets** as Supabase secrets. **Confirmed set as of
   2026-10-15** — no action remaining here: `OPENAI_API_KEY` (OpenAI-backed
   features), `GOOGLE_API` and `GOOGLE_VIDEO_API` (Gemini), plus GMAIL relay
   secrets, are all present; the 8/8 `ai:health` pass is the receipt, not a
   plan. Do not put provider credentials in the app bundle.

   **Video analysis is separate.** It calls Gemini, not OpenAI, and wants a
   plain API key from Google AI Studio — no service account, no YouTube upload:

   ```bash
   supabase secrets set GOOGLE_API=...
   ```

   Check configured AI routes through authorized QA; health probes require a
   signed-in test account and configured provider secrets.

The legal pages are published (§1). There is no owned canonical public app
origin yet: native referral/share links are deliberately omitted, preview-host
links fail closed, and production web auth-email redirects must wait until an
owned domain and SMTP are configured. Do not use a Lovable preview URL as the
public URL or as an auth destination.

---

## 0. Two decisions before you fill any form

**a) Target audience.** Play's "Target audience and content" section decides both
your Data safety answers and whether the Families policy applies to you.

Vaylo Sports collects health data, sells credits with real money, and runs branded
sponsor placements. Recommended answer: **13 and over**, with no appeal to children,
and "not designed for families". Do not pick an under-13 band — that pulls in COPPA
and the Families policy, which this app is not built for.

The app now enforces the age half of that: creating an account requires ticking a
"**I am 13 or older**" box that links to the Terms and the Privacy Policy
(`src/pages/Auth.tsx`). There are still no *other* age gates, date of birth remains
optional, and under-18s are handled by suppressing sponsored content and capping
training loads — not by blocking them.

**b) Ads: yes or no.** There is no advertising SDK in this app — no AdMob, no
mediation, and no advertising identifier permission in the manifest. But the app
does show **labelled sponsor placements** to adults (`SPONSORSHIP.md`,
`brand_placements`), and Play counts sponsored or branded promotion as ads.
Recommended answer: **"Yes, my app contains ads."** Declaring "no ads" while the
app renders sponsor placements is a misrepresentation risk with no upside: the
declaration costs nothing, and getting it wrong is a policy strike.

---

## 1. The legal pages (already published)

Live and verified on 28 September 2026 — all three return HTTP 200 with real
content and no unresolved placeholders:

| Play Console field | URL | Response |
|---|---|---|
| Privacy policy (App content) | `…/functions/v1/legal/privacy` | 200, 17 KB |
| — | `…/functions/v1/legal/terms` | 200, 11 KB |
| Data deletion → URL | `…/functions/v1/legal/account-deletion` | 200, 6 KB |

where `…` is `https://vvwhausdjzdmsyxekrcl.supabase.co`. Paste those two into
Play Console exactly as written — the full URL, not the shortened form.

To change the operator name or contact address, edit `legal/operator.json`, then:

```bash
node scripts/gen-legal-pages.cjs          # embeds the pages into the function
supabase functions deploy legal --no-verify-jwt
curl -sS -o /dev/null -w '%{http_code}\n' \
  "https://vvwhausdjzdmsyxekrcl.supabase.co/functions/v1/legal/privacy"
```

The function refuses to serve anything while `legal/operator.json` still holds its
`REPLACE_ME` placeholders, on purpose: a policy naming the wrong company, or
offering an inbox nobody reads, is worse than one that is temporarily unavailable,
and this URL is handed to Play.

**No owned public domain is configured.** Keep the live legal policy URLs on the
Supabase legal endpoint for Play Console. Do not use a Lovable preview hostname
for the optional website listing, public sharing, or authentication redirects.
Once an owned domain exists, host and verify the legal pages there before changing
the store listing or redirect configuration.

**`legal/` is not bundled into the app.** The in-app Privacy and Terms links in
Profile → Settings open these URLs in the in-app browser, so there is one copy of
each document and it cannot drift from what Play reviewed.

---

## 2. Build the signed bundle

Every upload needs a `versionCode` Play has never seen. The committed default is
`45` / `1.2.42`; bump it for each subsequent upload. Confirm the current version
in `android/app/build.gradle` before building, and use a version code greater
than every code already uploaded to Play.

**Locally** (needs `android/keystore.properties`, which is git-ignored alongside
the keystore):

```bash
npm run build:native
npx cap sync android
cd android
./gradlew bundleRelease -PversionCode=46 -PversionName=1.2.43
# → app/build/outputs/bundle/release/app-release.aab
```

`bundleRelease` **fails on purpose** if signing is not configured, rather than
emitting an unsigned bundle Play would reject with a less useful message.

**In CI** (Settings → Secrets and variables → Actions → *Secrets*):

| Secret | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | `base64 -w0 android/upload-keystore.jks` |
| `ANDROID_KEYSTORE_PASSWORD` | `storePassword` from `android/keystore.properties` |
| `ANDROID_KEY_ALIAS` | `upload` |
| `ANDROID_KEY_PASSWORD` | `keyPassword` from `android/keystore.properties` |

Then run the **android-release** workflow with a version code and name. It runs
typecheck, lint and the test suite first, builds, and verifies the bundle is signed
with the Vaylo Sports key before uploading the artifact.

Keep the keystore and its passwords somewhere you will still have them in five
years. Losing an upload key is recoverable (Play Console can reset it) but tedious.

---

## 3. Create the app and upload

1. Play Console → **Create app**. Name `Vaylo Sports`, English (US), **App**, **Free**.
2. Before the first upload, Play asks for three declarations: Play policies
   (yes), US export laws (yes), and whether the app contains ads (§0b).
3. **Testing → Closed testing → Create track → Manage testers**, then
   **Create new release** and upload the `.aab`.
4. Accept Play App Signing. Our key is the *upload* key; Google holds the app
   signing key and can re-sign if the upload key is ever lost.
5. Write release notes (max 500 characters per language).
6. Add testers by email list or Google Group. Testers must accept the opt-in link
   on a device signed into that Google account.

Add **yourself first** and check the opt-in link works before inviting anyone else:
a broken opt-in link is the most common reason a closed test silently has no
testers.

---

## 4. App content declarations

Play Console → Policy → **App content**. Every row below must be complete before
the release can roll out; the ones marked ⚠ change what you can ship.

| Declaration | Answer |
|---|---|
| Privacy policy | The §1 URL |
| Store listing → Website | Leave blank until an owned canonical website is available |
| App access | **All functionality is not available without special access.** Provide the demo account from §"What only you can provide" as email + password. |
| Ads | Per §0b — recommended **Yes** |
| ⚠ Content rating | Fill in the IARC questionnaire honestly. There is **user-generated content** (posts, comments, community messages, DMs) and **social features** (friends, leaderboards, challenges) — both are mandatory disclosures. There are in-app purchases and **simulated rewards** (credits, coins). No violence, no sexual content, no gambling, no controlled substances. Expect a Teen-ish rating. |
| Target audience | Per §0a — recommended **13+**, not designed for families |
| ⚠ Health apps | **Yes** — see §7 |
| Data safety | §5 |
| Government apps | No |
| Financial features | No (credits are not a financial product; purchases run through Play Billing) |
| News apps | No |
| COVID-19 contact tracing | No |
| Data deletion | **Yes, my app allows users to request deletion** → `…/functions/v1/legal/account-deletion`. Deletion is in-app and immediate; the page documents the email route for people who no longer have the app, which Play requires. |

⚠ The **content rating** row is the one most likely to go wrong. User-generated
content and social features must be declared, and the app must have moderation
available. It does — there is reporting and admin tooling under `src/pages/Admin*`
— but check that a report actually reaches a human before you answer, because that
is the thing Play's reviewers ask about next.

---

## 5. Data safety

Answer from what the code does, not from what the marketing says. Verified in this
repository:

**Collected (and why):**

| Category | Data | Purpose |
|---|---|---|
| Personal info | Name, email, user IDs, date of birth (optional) | Account, app functionality |
| Health and fitness | Fitness info (workouts, distance, calories, steps), health info (heart rate, sleep) | App functionality |
| Financial info | Purchase history (credits, coins, subscription) | App functionality |
| Messages | In-app messages (coach chat, community, DMs) | App functionality |
| Photos and videos | Photos (profile, avatar), videos (form analysis uploads) | App functionality |
| App activity | App interactions, other user-generated content | App functionality, analytics? → **no**, there is no analytics SDK |
| Crash logs, diagnostics | Failure reports the app itself sends (error name/message, redacted stack, screen, platform, version — no tokens, no health values) | App functionality |

**Not collected:**

- **Location.** Worth stating explicitly because it is a plausible mistake: the
  app collects no location at all. Nothing calls `navigator.geolocation`, the
  manifest declares **no location permission**, and a workout's distance is a
  figure the athlete types in (`src/pages/Workouts.tsx`, stored as
  `workouts.distance_km`). There is no coordinate anywhere to discard.
- **Payment info.** Handled entirely by Google Play.
- **Contacts, calendar, audio, files, web browsing, device or other IDs.** No SDK
  or permission touches any of these.

**Shared with third parties:** Yes — to OpenAI (text of AI features) and Google
(Gemini for video form analysis, Play Billing). Both must be declared as
processors with "app functionality" as the purpose. Sponsor partners receive
**aggregate counts only**; no personal or health data (`brand_metrics` has no
user-identifying column). Do not declare them as recipients of personal data.

Also declare: data is **encrypted in transit**, and users **can request deletion**
(the in-app flow, and the §1 URL).

---

## 6. Store listing

Required assets, and where they are:

| Asset | Spec | Status |
|---|---|---|
| App icon | 512×512 PNG, 32-bit, ≤1 MB | `store/icon-512.png` (75 KB) |
| Feature graphic | 1024×500 JPEG or 24-bit PNG, no alpha | `store/feature-graphic-1024x500.jpg` (50 KB) |
| Phone screenshots | 2–8, 16:9 or 9:16, 320–3840 px | **Not done** |
| App name | ≤30 chars | `Vaylo Sports` |
| Short description | ≤80 chars | **Write it** |
| Full description | ≤4000 chars | **Write it** |

Regenerate the two images with:

```bash
powershell -NoProfile -ExecutionPolicy Bypass -File scripts/gen-store-assets.ps1
```

The icon is rendered from `ic_launcher.png` — the launcher artwork, so the store
icon and the home screen agree. It is a 192 px source upscaled to 512; the design
is flat (761 distinct colours), so it holds up, but a vector or 1024 px export
would replace it cleanly if the brand is ever redrawn.

**Screenshots** are captured from the running app rather than generated:

```bash
adb shell screencap -p /sdcard/shot.png && adb pull /sdcard/shot.png store/screenshots/
```

Capture at least four: the Today/Hub screen, the coach or a training plan, a
progress chart, and the market or an event. Take them on a **wide** phone profile
(1080×2340 is fine) and avoid showing real personal data — use the demo account.

---

## 7. Health apps declaration

Because the app requests Health Connect permissions, Play requires an approved
**Health apps** declaration (App content → Health apps). Complete it before
rollout; the release cannot go out while it is outstanding.

Declare at minimum:

- **Health Connect** as the data source, with the six record types the manifest
  asks for: exercise, distance, total calories burned, heart rate, steps, sleep.
- **Fitness and wellness** as the feature type.
- That the purpose is training and recovery guidance, not diagnosis or treatment.

Two things already in place that this form depends on:

- **The permission rationale page.** `public/health-rationale.html` explains each
  record type, what happens to it, and how to revoke access. Android routes the
  Android 13 rationale intent and the Android 14 `VIEW_PERMISSION_USAGE` intent
  there (`MainActivity.onNewIntent`); without that it would open the app on
  whatever screen was last shown, which fails the requirement.
- **Read-only access.** The manifest requests no Health Connect write permission,
  and the app has no path to write to it.

Health Connect itself supports Android 8+ at the SDK level, so `minSdk 26` is
correct as it stands — but note that the Health Connect *app* only runs on
Android 9+, so on Android 8 there is nothing to connect to.

---

## 8. Play Billing

Purchases cannot be tested in a closed track until this is done, and the app
currently cannot verify any purchase because the server side is unconfigured
(`PAYMENT_MODE` is set but the Google credentials are not).

1. Play Console → **Monetise → Products** → create the in-app products and
   subscriptions the app sells. The catalogue is generated: read the ids from
   `supabase/functions/_shared/moneyCatalog.ts` and the subscription ids from the
   pricing config, and do not invent new ones — the app grants only what it can
   look up by id.
2. Play Console → **Setup → API access** → create a service account, grant it
   *Financial data* → *View financial data*, and download its JSON key.
3. Set the secrets the verifier needs:

   ```bash
   supabase secrets set \
     GOOGLE_SERVICE_ACCOUNT_EMAIL=... \
     GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n" \
     GOOGLE_ANDROID_PACKAGE_NAME=com.vaylosports.app
   ```

4. Add testers to **License testing** (Setup → License testing) so purchases are
   free and can be repeated.
5. Set `PAYMENT_MODE=store` when you are ready to verify real purchases. The test mode is for local development only and must never be enabled in a deployed project.

Event Packs are currently bought with **credits**, not cash, so they work in a
closed test today without any of the above. Credits themselves cannot be bought
until Billing is configured — testers will see the purchase fail.

---

## 9. Roll out

1. Complete every row in §4 — Play blocks the rollout with a checklist.
2. Upload the bundle (§2), write release notes, review, **Start rollout**.
3. Add testers, then have each one open the opt-in link and install from Play.
4. Watch **Quality → Android vitals** for crashes during the test. A closed test
   is where a crash-only-on-a-real-device shows up.

If it is your first release, expect **1–7 days** for review of a closed test.

---

## 10. Version discipline

- Never reuse a `versionCode`. Play rejects the whole upload.
- Bump `versionCode` per upload (`-PversionCode=`); only bump the `versionName`
  default in `android/app/build.gradle` when it is worth a commit.
- Keep the upload key and its passwords backed up. If you lose them, Play Console
  → Test and release → Setup → App signing → *Request upload key reset*.
- The `.aab` is **not** in git (`android/.gitignore` excludes `*.aab`), and neither
  is the web bundle under `android/app/src/main/assets/public`, because
  `npx cap sync` regenerates it from `dist/`.

---

## Pre-launch checklist

Updated 2026-10-15. Ordered by what actually blocks a rollout, not by
convenience. Everything in **Tier 0** is a real exposure or a lost conversion;
everything in **Tier 4** can wait until after closed testing.

### Tier 0 — today, about 15 minutes, all yours

| | Task | Why |
|---|---|---|
| ☐ | **Rotate the Play reviewer password** | It is recoverable from 5 commits on `origin/main` — see SECURITY.md finding 14. This is the only open item on this page that is an active exposure. |
| ☐ | Auth Dashboard → rate-limit wrong passwords | `npm run auth:posture` reports 3 of 3 at risk. |
| ☐ | Auth Dashboard → min password length 6 → 8 | As above. |
| ☐ | **Leave "require email confirmation" OFF** | It looks like a fix for the third posture finding and it would break the closed test. Testers sign up with an address they cannot verify and every one of them is locked out at the first screen. Turn it on *after* closed testing, once onboarding is yours. |

### Tier 1 — the build, done in this repository

The closed-test bundle should not contain a feature that visibly does nothing.
As of this commit it does not:

| Feature | How it is handled |
|---|---|
| **Wearable sync** | `wearableSync` flag, **on**. `/health-sync` is reachable from the sidebar, the Recover hub and the route. Health Connect is complete and shipping — native plugin, six read permissions, incremental pull — and only providers with `available: true` are rendered, so the cloud providers that have no OAuth secrets yet are labelled as unconfigured rather than promised. |
| **GPS tracking** | Removed, not hidden. Nothing calls `navigator.geolocation` and distance is a figure the athlete types in, so there is no inert control left for a tester to find. The `gpsTracking` flag is still defined and off by default, but nothing reads it. |
| **Coach marketplace** | `coachMarketplace` flag, already off before this change. |
| **AI** | **Not flagged, on purpose.** AI is inside the core pages — Training generates the plan, FormAnalysis / Nutrition / Tactics analyse, Goals writes the weekly review, Coach chats. A flag would not hide a feature, it would gut the product. The athlete already sees "not switched on yet"; the real fix is `supabase secrets set OPENAI_API_KEY=…`. **If you are choosing between adding that key and adding a flag, add the key.** |

To build a bundle that *shows* one of these, set the override — see
`.env.example`:

```bash
VITE_ENABLE_coachMarketplace=true   # gpsTracking no longer has a consumer
```

Overrides are build-time and per-machine. No owned public website is currently
configured, so external links from native remain disabled rather than pointing
to a project preview. Any hosted web deployment must configure its owned origin
before enabling referral/auth links.

### Tier 2 — Play Console forms, about 2 hours, all yours

Nothing in this repository does these, and you need them before the *first*
rollout to a closed track, not before production.

- ☐ **Health apps declaration** — the one that will generate questions. Reading
  Health Connect data makes this a health app, which brings extra scrutiny and
  requires the privacy policy to cover health data specifically. Start it first.
- ☐ **Data safety** — declare Health Connect, account credentials, and whatever
  the AI features would send. The location question resolves itself: nothing in
  the app asks for location.
- ☐ **Content rating** questionnaire.
- ☐ **Target audience and content**.
- ☐ **Store listing** — screenshots are still not captured (§6). Title must be
  "VAYLO Sports" with a capital S.

### Tier 3 — the artefact, about 30 minutes

- ☐ Signed bundle via the `android-release` workflow. Signing is configured, the
  upload key is valid to 2054, and the release build compiles clean. This is
  paperwork, not engineering.

### Tier 4 — after closed testing

Email confirmation · wearable vendor agreements · owned public domain · legal
entity and ICO registration · Supabase SMTP for password reset.

One item is mis-tiered and worth knowing: **password-reset email** depends on
Supabase's built-in sender, which is rate-limited. A reviewer using the account
you hand them will not hit it; a tester who mistypes their email on signup will.

### Tier 3.5 — cookie / tracking posture (done in this repository)

This app sets **no cookies and no tracking identifiers**, so there is no consent
gate to build and no consent record to store. The website shows a short cookie
notice at the foot of the page; pressing Accept writes a single on-device
`localStorage` entry (`vaylo:cookie-notice`, versioned) recording that the reader
has seen it. Nothing is sent to Vaylo's servers, nothing is gated, and clearing
site data brings the notice back — which is the correct behaviour rather than a
bug. The same notice is now wired into the app shell, so the APK and the
downloadable web-app clone surface the same notice as the website.

Before you submit, confirm these three things rather than assume:

| | Check | Where |
|---|---|---|
| ☐ | No cookie is set by the website on first hit | `curl -c /tmp/cookies.txt -b /tmp/cookies.txt -s -o /dev/null -w '%{http_code}\n' https://vaylo-sports.netlify.app/` then inspect `/tmp/cookies.txt` — should be empty of any Vaylo cookie |
| ☐ | The cookie notice shows on the live marketing home | Open `https://vaylo-sports.netlify.app/` in a browser; the notice region (`data-cookie-notice`, "No tracking cookies") should be visible once per device, and the Accept button should hide it |
| ☐ | The Cookie Policy page resolves from the app and from the clone | In-app, `/legal/cookies` opens the `LegalDocument` component; on the clone, the Legal screen links to the Cookie Policy; on the website, `https://vaylo-sports.netlify.app/legal/cookies/` returns HTTP 200 with the full policy ("No cookies at all") |

If the marketing home does **not** show the notice, the website deploy is stale:

```bash
cd website
npx netlify deploy --no-build --prod --site=388b0b24-27ee-472b-9197-aa8eb2782493
curl -s https://vaylo-sports.netlify.app/ | grep -c "data-cookie-notice"
```

The last deploy of that site failed with **403: account credit usage exceeded** —
new deploys are blocked until credits are added in the Netlify account. Until that
clears, the live marketing home stays stale even though `website/index.html` is
correct. The APK and the clone are unaffected (their notice is in the app bundle,
not on the marketing host).

Note for the Data safety form: the app collects **no advertising ID**, declares **no
cookies**, and shares **no advertising or analytics identifiers** with third parties.
Sponsor placements are labelled and report only aggregate counts. Decline any
"do you use cookies for advertising/personalisation" prompt that the store or a
reviewer throws at you — the honest answer for this app is no, with the cookie
notice as the evidence. The app's advertising-identifier posture is documented in
`legal/cookies.html` and `legal/advertising.html`.

### The 14-day clock

Check the current Play Console requirement for your account type before planning production access. The 12-testers-for-14-continuous-days rule applies to production-access eligibility for certain newer personal developer accounts, not universally to every closed-testing track. If it applies, the clock starts when the track is live.

## Known gaps

These are not Play blockers, but they are real and they will surface in a review
if a tester goes looking. Item 1 is now handled rather than left for a tester to
find — see the pre-launch checklist above.

1. **GPS tracking is gone, not merely inert.** The app no longer calls
   `navigator.geolocation` anywhere and the manifest declares no location
   permission, so distance is a figure the athlete types in. The `gpsTracking`
   flag is still defined and off, but nothing reads it. To bring live tracking
   back: add `ACCESS_FINE_LOCATION` plus a WebView geolocation grant, wire the
   control to the flag, and declare location in Data safety.
2. **AI feature availability depends on provider secrets.** Ensure OpenAI routes
   have `OPENAI_API_KEY` and video form analysis has `GOOGLE_API` configured in
   Supabase before advertising those routes as available to reviewers.
3. **The cloud wearable providers are unconfigured — Health Connect is not.**
   `wearable-oauth` answers `not_configured` for every cloud provider because no
   vendor OAuth secrets exist; Garmin, Strava and the rest each need a developer
   agreement signed by a human. The surface ships anyway (`wearableSync` is on)
   because Health Connect works, and each unconfigured provider is labelled as
   such on the screen rather than promised.
4. **Password-reset email delivery** depends on Supabase's SMTP configuration; the
   built-in sender is rate-limited and unsuitable for real users.
5. **No owned canonical website is configured.** Do not put a Lovable preview
   domain in the Play listing or auth redirect allowlist. Leave the optional
   website field blank until the owned public origin is selected and deployed.
6. **No registered legal entity yet.** The policy names "Vaylo Sports" as the data
   controller, which is what a trading name is for, and it works with a working
   contact address. When there is a limited company, put its registered name in
   `legal/operator.json` and redeploy. If you are in the UK, processing personal
   data also means registering with the ICO and paying the data protection fee
   unless an exemption applies — that is a legal step, not a technical one, and
   nothing in this repository does it for you.
