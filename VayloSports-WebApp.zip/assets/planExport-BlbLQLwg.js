const s=(e,t=2)=>String(e).padStart(t,"0"),p=e=>{const t=new Date(`${e}T09:00:00`);return`${t.getFullYear()}${s(t.getMonth()+1)}${s(t.getDate())}T${s(t.getHours())}${s(t.getMinutes())}00`},i=e=>{if(e.length<=73)return e;const t=[];let n=e;for(t.push(n.slice(0,73)),n=n.slice(73);n.length>0;)t.push(` ${n.slice(0,73)}`),n=n.slice(73);return t.join(`\r
`)},c=e=>e.replace(/\\/g,"\\\\").replace(/;/g,"\\;").replace(/,/g,"\\,").replace(/\n/g,"\\n"),d=e=>`vaylo-${e.id}@vaylosports.app`;function g(e,t){const n=e.filter(a=>!a.isRest),l=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Vaylo Sports//Training Plan//EN","CALSCALE:GREGORIAN","METHOD:PUBLISH",`X-WR-CALNAME:${c(t)}`];for(const a of n)l.push("BEGIN:VEVENT",`UID:${d(a)}`,`DTSTAMP:${p(a.scheduled_date)}`,`DTSTART;VALUE=DATE:${a.scheduled_date.replace(/-/g,"")}`,`SUMMARY:${c(a.title)}`,`DESCRIPTION:${c(`Vaylo Sports — ${a.type}. Week ${a.week} of the plan. Open Vaylo Sports to log this session.`)}`,"TRANSP:TRANSPARENT","END:VEVENT");return l.push("END:VCALENDAR"),l.map(i).join(`\r
`)+`\r
`}const r=e=>e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;"),u=e=>`${e}T09:00:00Z`;function $(e,t){const n=e.filter(o=>!o.isRest),l=`<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="Vaylo Sports" xmlns="http://www.topografix.com/GPX/1/1">
  <metadata>
    <name>${r(t)}</name>
    <desc>${r(`Training plan export — ${n.length} planned sessions`)}</desc>
  </metadata>
`,a=n.map(o=>`  <wpt lat="0" lon="0">
    <name>${r(`W${o.week} ${o.title}`)}</name>
    <desc>${r(`${o.type} — scheduled ${o.scheduled_date}`)}</desc>
    <time>${u(o.scheduled_date)}</time>
  </wpt>
`).join("");return l+a+`</gpx>
`}function E(e,t,n){return n==="ics"?g(e,t):$(e,t)}function h(e){const t=new Date;return`vaylo-plan-${t.getFullYear()}-${s(t.getMonth()+1)}-${s(t.getDate())}.${e}`}export{g as a,E as b,h as p};
