import{j as r}from"./motion-DMv9DuUZ.js";import{N as t}from"./react-BlN8v7Yd.js";function e(){return r.jsx(t,{to:"/subscription",replace:!0})}export{e as default};
