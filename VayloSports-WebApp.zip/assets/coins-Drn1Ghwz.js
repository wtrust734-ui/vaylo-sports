import{e as s}from"./index-BNGoinNg.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=s("ArrowRightLeft",[["path",{d:"m16 3 4 4-4 4",key:"1x1c3m"}],["path",{d:"M20 7H4",key:"zbl0bi"}],["path",{d:"m8 21-4-4 4-4",key:"h9nckh"}],["path",{d:"M4 17h16",key:"g4d7ey"}]]),t={label:"Free during closed testing",shortLabel:"Free",explanation:"You are in a closed test, so credits are free right now. Nothing is charged and no card is taken. Paid credits arrive with Google Play billing after closed testing ends."},o=7.5,c=[{id:"coins_120",coins:120,bonus:0,price_cents:299,label:"Starter"},{id:"coins_300",coins:300,bonus:30,price_cents:599,label:"Value"},{id:"coins_800",coins:800,bonus:120,price_cents:1299,label:"Popular",popular:!0},{id:"coins_2000",coins:2e3,bonus:500,price_cents:2499,label:"Pro"},{id:"coins_5000",coins:5e3,bonus:2500,price_cents:3749,label:"Mega",best_value:!0}],r={id:"coins_first",coins:700,bonus:0,price_cents:199,label:"First buy · one only"};function a(e){return Math.floor(e*o)}export{n as A,t as C,r as F,c as a,o as b,a as c};
